OmoFun动漫 · iOS 工程（生成 .ipa 用）
=====================================

这里是什么
----------
一套完整、可直接编译的 iOS 工程（Swift + WKWebView），以及一个 GitHub Actions
配置：把整个目录推到 GitHub 仓库后，云端 macOS 机器会自动编译出
OmoFun-unsigned.ipa 供你下载，不需要你有 Mac。

目录结构
  .github/workflows/ios-build.yml   云端自动打包脚本
  ios/project.yml                   XcodeGen 工程描述
  ios/OmoFun/AppDelegate.swift      入口
  ios/OmoFun/WebViewController.swift WKWebView 主体
  ios/OmoFun/Info.plist             应用配置（名称、ATS、方向、文件共享）
  ios/OmoFun/Assets.xcassets/       图标 1024x1024、启动屏背景色

App 功能
  · 全屏 WKWebView 打开 https://www.omofuns.com/
  · 顶部细进度条、深色背景、断网中文错误页 + 重新加载
  · 支持网页 JS 弹窗（alert/confirm/prompt）、target=_blank 同窗口打开
  · 视频内联/全屏播放、手势滑动返回
  · 网页内下载保存到「文件」App → 我的 iPhone → OmoFun
  · Cookie 持久化，登录状态保留

路线一：没有 Mac（推荐，全程免费）
----------------------------------
1. 注册/登录 GitHub，新建一个仓库（Private 也行）。
2. 把本目录（连同隐藏的 .github 文件夹）上传到仓库根目录。
   网页上传没法传 .github？用 GitHub Desktop，或把 .github/workflows/ios-build.yml
   用网页编辑器手动新建同名文件粘贴内容。
3. 打开仓库 Actions 标签 → 左侧 “Build unsigned IPA” → Run workflow。
   约 5-8 分钟后，页面底部 Artifacts 里下载 OmoFun-unsigned-ipa.zip，解压得到
   OmoFun-unsigned.ipa。
4. 这个 ipa 是「未签名」的，iPhone 不能直接装，需要用自己的 Apple ID 重签：
   · Windows 上装 Sideloadly（sideloadly.io）+ 苹果驱动（iTunes 或 Apple Devices）；
   · iPhone 用数据线连电脑，Sideloadly 里拖入 ipa，填你的 Apple ID，
     点 Start，按提示在手机上「信任」开发者证书。
   · 免费 Apple ID 签名的 App 有效期 7 天，到期用同样步骤重签即可。
   （AltStore 也是同一原理，需要 Windows 上常驻 AltServer。）

路线二：有 Mac
--------------
1. brew install xcodegen
2. cd ios && xcodegen generate
3. open OmoFun.xcodeproj
4. 在 Signing & Capabilities 里选你的 Team（免费 Apple ID 也可以），
   连上 iPhone 直接 Run；或 Product → Archive 导出 ipa。

路线三：有付费开发者账号（99 美元/年）
--------------------------------------
把 project.yml 里的 DEVELOPMENT_TEAM 换成你的 Team ID，Archive 后上传 App Store
Connect，用 TestFlight 分发给别人安装（有效期 90 天一轮），这是唯一能给别人装、
又不用对方电脑的正规方式。

为什么不能直接给你一个现成 ipa
------------------------------
iOS 只运行 Apple 工具链编译、且带 Apple 签名（或企业/开发者证书签名）的二进制。
本机是 Windows，没有 iOS SDK 也无法苹果签名，任何在这里拼出来的 ipa 传到 iPhone
都会安装失败。上面路线一用免费的 GitHub macOS 机器完成“编译”，再用你的 Apple ID
完成“签名”，是在没有开发者账号时唯一可行的组合。

改内容
------
· 换首页地址：ios/OmoFun/WebViewController.swift 里的 homeURL
· 换 App 名称/包名：ios/OmoFun/Info.plist 的 CFBundleDisplayName；
  ios/project.yml 的 PRODUCT_BUNDLE_IDENTIFIER
· 换图标：替换 ios/OmoFun/Assets.xcassets/AppIcon.appiconset/icon-1024.png
  （必须是 1024x1024、无透明通道的 PNG）

注意
----
工程在本机（Windows）无法编译验证，Swift 代码按 iOS 15+ 标准 API 编写；
如云端构建报错，把 Actions 报错日志发我，我按日志修。
